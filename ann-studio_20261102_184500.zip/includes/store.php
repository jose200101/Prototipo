<?php
declare(strict_types=1);
date_default_timezone_set('America/Tegucigalpa');
const DATA_DIR = __DIR__ . '/../data';

function h(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function data_file(string $name): string { return DATA_DIR . '/' . $name . '.json'; }
function read_json(string $name, array $fallback = []): array {
  $file = data_file($name);
  if (!is_file($file)) return $fallback;
  $decoded = json_decode((string)file_get_contents($file), true);
  return is_array($decoded) ? $decoded : $fallback;
}
function write_json(string $name, array $data): bool {
  if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0755, true);
  return file_put_contents(data_file($name), json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX) !== false;
}
function product_with_image(array $product): array {
  if (!empty($product['image'])) return $product;
  $product['image'] = match ($product['category'] ?? '') {
    'Carteras' => 'assets/products/demo-handbag.jpg',
    'Lociones', 'Gafas', 'Accesorios' => 'assets/products/demo-beauty.jpg',
    default => 'assets/products/demo-fashion.jpg',
  };
  return $product;
}
function store_products(): array { return array_values(array_map('product_with_image', array_filter(read_json('products'), fn($p) => ($p['active'] ?? true)))); }
function store_categories(): array { return ['Todos','Ropa','Lociones','Carteras','Gafas','Accesorios']; }
function json_response(array $data, int $status = 200): never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function request_json(): array { $data = json_decode((string)file_get_contents('php://input'), true); return is_array($data) ? $data : $_POST; }
function client_hash(): string { return substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . 'ann-studio'), 0, 16); }
function clean_text(mixed $v, int $max = 120): string { return mb_substr(trim((string)$v), 0, $max); }
